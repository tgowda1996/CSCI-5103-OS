#include "fs.h"
#include "disk.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>

#define FS_MAGIC           0xf0f03410
#define INODES_PER_BLOCK   128
#define POINTERS_PER_INODE 5
#define POINTERS_PER_BLOCK 1024

// Returns the number of dedicated inode blocks given the disk size in blocks
#define NUM_INODE_BLOCKS(disk_size_in_blocks) (1 + (disk_size_in_blocks / 10))

int* block_freemap;
int* inode_freemap;
int numblocks = -1;
int numinodes = -1;

struct fs_superblock {
  int magic;          // Magic bytes
  int nblocks;        // Size of the disk in number of blocks
  int ninodeblocks;   // Number of blocks dedicated to inodes
  int ninodes;        // Number of dedicated inodes
};

struct fs_inode {
  int isvalid;                      // 1 if valid (in use), 0 otherwise
  int size;                         // Size of file in bytes
  int direct[POINTERS_PER_INODE];   // Direct data block numbers (0 if invalid)
  int indirect;                     // Indirect data block number (0 if invalid)
};

union fs_block {
  struct fs_superblock super;               // Superblock
  struct fs_inode inode[INODES_PER_BLOCK];  // Block of inodes
  int pointers[POINTERS_PER_BLOCK];         // Indirect block of direct data block numbers
  char data[DISK_BLOCK_SIZE];               // Data block
};

int inode_load(int inumber, struct fs_inode* inode) {
  int inode_block_number = 1 + inumber / INODES_PER_BLOCK; 
  if (numinodes == -1 || inode_block_number >= numinodes / INODES_PER_BLOCK) {
    return 0;
  } // if
  union fs_block block;
  disk_read(inode_block_number, block.data);
  *inode = block.inode[inumber % INODES_PER_BLOCK]; 
  return 1;
} // inode_load()

int inode_save(int inumber, struct fs_inode* inode) {
  int inode_block_number = 1 + inumber / INODES_PER_BLOCK; 
  if (numinodes == -1 || inode_block_number >= numinodes / INODES_PER_BLOCK) {
    return 0;
  } // if
  union fs_block block;
  disk_read(inode_block_number, block.data);
  block.inode[inumber % INODES_PER_BLOCK] = *inode;
  disk_write(inode_block_number, block.data);
  return 1;
} // inode_save()

void print_block_freemap() {
  printf("  block_freemap:\n");
  for (int i = 0; i < numblocks; i++) {
    printf("    Block %d -> %d\n", i, block_freemap[i]);
  } // for
} // print_freemap()

void print_inode_freemap() {
  printf("  inode_freemap:\n");
  for (int i = 0; i < numinodes; i++) {
    printf("    inode %d -> %d\n", i, inode_freemap[i]);
  } // for
} // print_freemap()

void fs_debug() {
  union fs_block super_block;
  // superblock
  disk_read(0, super_block.data);
  printf("superblock:\n");
  if (super_block.super.magic != FS_MAGIC) {
    printf("    magic number is invalid\n");
    return;
  } // if
  printf("    %d blocks\n",super_block.super.nblocks);
  printf("    %d inode blocks\n",super_block.super.ninodeblocks);
  printf("    %d inodes\n",super_block.super.ninodes);
  // inodes
  union fs_block inode_block;
  for (int i = 0; i < super_block.super.ninodeblocks; i++) {
    assert(i + 1 < super_block.super.nblocks);
    disk_read(i + 1, inode_block.data);
    for (int j = 0; j < INODES_PER_BLOCK; j++) {
      struct fs_inode inode = inode_block.inode[j];
      if (inode.isvalid) { // in use
        printf("inode %d:\n", j + i * INODES_PER_BLOCK);
        printf("    size: %d bytes\n",inode.size);
        // direct blocks
        printf("    direct blocks:");
        for (int k = 0; k < POINTERS_PER_INODE; k++) {
          if (inode.direct[k]) { // valid
            printf(" %d", inode.direct[k]);
          } else {
            break;
          } // else
        } // for k
        printf("\n");
        // indirect blocks
        if (inode.indirect) { // valid
          printf("    indirect block: %d\n", inode.indirect);
          union fs_block pointer_block;
          disk_read(inode.indirect, pointer_block.data);
          printf("    indirect data blocks:");
          for (int k = 0; k < POINTERS_PER_BLOCK; k++) {
            if (pointer_block.pointers[k]) {
              printf(" %d", pointer_block.pointers[k]);
            } else {
              break;
            } // else
          } // for k
          printf("\n");
        } // if inode.indirect 
      } // if inode.isvalid
    } // for j
  } // for i
} // fs_debug()

int fs_format() {
  if (block_freemap || inode_freemap) { // mounted
    printf("Unmount before formatting\n");
    return 0;
  } // if
  // initialize the superblock
  union fs_block block;
  block.super.magic = FS_MAGIC;
  block.super.nblocks = disk_size();
  int num_inode_blocks = NUM_INODE_BLOCKS(block.super.nblocks);
  block.super.ninodeblocks = num_inode_blocks;
  block.super.ninodes = num_inode_blocks * INODES_PER_BLOCK;
  // initialize the inodes 
  union fs_block inode = {0};
  for (int i = 0; i < num_inode_blocks; i++) {
    assert(i + 1 < block.super.nblocks);
    disk_write(i + 1, inode.data);
  } // for
  // write superblock to disk
  disk_write(0, block.data); 
  return 1;
} // fs_format()

int fs_mount() {
  // read superblock
  union fs_block super_block;
  disk_read(0, super_block.data);
  if (super_block.super.magic != FS_MAGIC) {
    return 0;
  } // if
  // initialize freemaps
  numblocks = super_block.super.nblocks;
  numinodes = super_block.super.ninodes;
  block_freemap = (int *) calloc(numblocks, sizeof(int));
  if (block_freemap == NULL) {
    perror("Error - failed to allocate memory for block_freemap");
    return 0;
  } // if
  inode_freemap = (int *) calloc(numinodes, sizeof(int));
  if (inode_freemap == NULL) {
    perror("Error - failed to allocate memory for inode_freemap");
    return 0;
  } // if
  block_freemap[0] = 1;
  // traverse all valid inodes
  union fs_block inode_block;
  for (int i = 0; i < super_block.super.ninodeblocks; i++) {
    assert(i + 1 < super_block.super.nblocks);
    disk_read(i + 1, inode_block.data);
    block_freemap[i + 1] = 1;
    for (int j = 0; j < INODES_PER_BLOCK; j++) {
      struct fs_inode inode = inode_block.inode[j];
      if (inode.isvalid) { // in use
        inode_freemap[j + i * INODES_PER_BLOCK] = 1;
        // direct blocks
        for (int k = 0; k < POINTERS_PER_INODE; k++) {
          if (inode.direct[k]) { // valid
            block_freemap[inode.direct[k]] = 1;
          } else {
            break;
          } // else
        } // for k
        // indirect blocks
        if (inode.indirect) { // valid
          union fs_block pointer_block;
          disk_read(inode.indirect, pointer_block.data);
          for (int k = 0; k < POINTERS_PER_BLOCK; k++) {
            if (pointer_block.pointers[k]) {
              block_freemap[pointer_block.pointers[k]] = 1;
            } else {
              break;
            } // else
          } // for k
        } // if inode.indirect 
      } // if inode.isvalid
    } // for j
  } // for i
  return 1;
} // fs_mount()

int fs_unmount() {
  if (block_freemap || inode_freemap) { // mounted
    free(block_freemap);
    block_freemap = NULL;
    numblocks = -1;
    free(inode_freemap);
    inode_freemap = NULL;
    numinodes = -1;
    return 1;
  } // if
  printf("Not currently mounted\n");
  return 0;
} // fs_unmount()

int fs_create() {
  if (block_freemap || inode_freemap) { // mounted
    // find a free inode
    for (int i = 0; i < numinodes; i++) {
      if (!inode_freemap[i]) {
        // allocate inode
        struct fs_inode inode = {0};
        inode.isvalid = 1;
        int res = inode_save(i, &inode);
        if (!res) {
          return -1;
        } // if
        inode_freemap[i] = 1;
        return i;
      } // if
    } // for
  } // fs_unmount()
  printf("Must be mounted to perform create\n");
  return -1;
} // fs_create()

int fs_delete(int inumber) {
  if (block_freemap || inode_freemap) { // mounted
    struct fs_inode inode;
    int res = inode_load(inumber, &inode);
    if (!res || !inode.isvalid) {
      return 0;
    } // if
    // free direct pointers
    for (int i = 0; i < POINTERS_PER_INODE; i++) {
      if (inode.direct[i]) {
        block_freemap[i] = 0;
      } else {
        break;
      } // else
    } // for
    // free indirect pointers
    if (inode.indirect) {
      union fs_block pointer_block;
      disk_read(inode.indirect, pointer_block.data);
      for (int i = 0; i < POINTERS_PER_BLOCK; i++) {
        if (pointer_block.pointers[i]) {
          block_freemap[pointer_block.pointers[i]] = 0;
        } else {
          break;
        } // else
      } // for
      block_freemap[inode.indirect] = 0;
    } // if
    // invalidate inode
    struct fs_inode empty_inode = {0};
    res = inode_save(inumber, &empty_inode);
    if (!res) {
      return 0;
    } // if
    inode_freemap[inumber] = 0;
    return 1;
  } // if
  printf("Must be mounted to perform delete\n");
  return 0;
} // fs_delete()

int fs_getsize(int inumber) {
  if (block_freemap || inode_freemap) { // mounted
    struct fs_inode inode;
    int res = inode_load(inumber, &inode);
    if (!res || !inode.isvalid) {
      return -1;
    } // if
    return inode.size;
  } // if
  printf("Must be mounted to perform getsize\n");
  return -1;
} // fs_getsize()

int fs_read(int inumber, char *data, int length, int offset) {
  return 0;
} // fs_read()

int fs_write(int inumber, const char *data, int length, int offset) {
  return 0;
} // fs_write()
