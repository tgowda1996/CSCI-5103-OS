## CSCI-5103-Project-4

### Team members
- Anthony Dierssen-Morice (diers040)
- Tushar Gowda (gowda019)

### fs_format
In order to test the `fs_format` function, the following commands were run:
```
[19:30:13]$ ./simplefs mydisk 50
opened emulated disk image mydisk with 50 blocks
 simplefs> debug
superblock:
    magic number is invalid
 simplefs> mount
mount failed!
 simplefs> format
disk formatted.
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
 simplefs> exit
Not currently mounted
closing emulated disk.
9 disk block reads
7 disk block writes
[19:31:08]$ ./simplefs mydisk 50
opened emulated disk image mydisk with 50 blocks
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
 simplefs> exit
Not currently mounted
closing emulated disk.
7 disk block reads
0 disk block writes
```
The above test shows that a newly created, unformatted disk does not contain any
file system, and, thus, cannot be mounted. After formatting the disk, however, we can
run `debug` to see that a file system does now exist--indicating a successful
format. To show that the disk image persists, we then exit and relaunch the same
disk image to find that `debug` does, in fact, confirm that the disk is still
formatted.

### fs_create
In order to test the `fs_create` function, the following commands were run:
```
[19:39:52]$ ./simplefs mydisk 50
opened emulated disk image mydisk with 50 blocks
 simplefs> format
disk formatted.
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
 simplefs> mount
disk mounted.
 simplefs> create
created inode 0
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
inode 0:
    size: 0 bytes
    direct blocks:
 simplefs> create
created inode 1
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
inode 0:
    size: 0 bytes
    direct blocks:
inode 1:
    size: 0 bytes
    direct blocks:
 simplefs> exit   
closing emulated disk.
30 disk block reads
9 disk block writes
```
In the above test we format a newly created disk, mount the disk, and then
create a new file. The subsequent call to `debug` shows that the file has been
created successfully. For good measure, a second file is created and `debug` is
called again to verify that everything is as expected.

### fs_mount and fs_unmount
In order to test the `fs_mount` and `fs_unmount` functions, the following commands were run:
```
[19:47:10]$ ./simplefs mydisk 50
opened emulated disk image mydisk with 50 blocks
 simplefs> format
disk formatted.
 simplefs> create
Must be mounted to perform create
create failed!
 simplefs> mount
disk mounted.
 simplefs> create
created inode 0
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
inode 0:
    size: 0 bytes
    direct blocks:
 simplefs> format
Unmount before formatting
format failed!
 simplefs> unmount
disk unmounted.
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
inode 0:
    size: 0 bytes
    direct blocks:
 simplefs> format
disk formatted.
 simplefs> debug
superblock:
    50 blocks
    6 inode blocks
    768 inodes
 simplefs> exit
Not currently mounted
closing emulated disk.
29 disk block reads
15 disk block writes
```
In the above test we first format a newly created disk. With the formatted disk,
we attempt to create a new file. This operation fails because the disk is not
mounted. As such, we mount the disk before proceeding to successfully create a
file, thereby indicating that the disk is actually mounted. Next, we attempt to
format the disk. This action fails because the disk is mounted. As such, we
unmount the disk before attempting to format the disk again. The format then
succeeds indicating the unmount was successful.

### fs_debug
observe the following output obtained from the solution executable:
```
[19:53:57]$ ./simplefs-solution image.200 200
opened emulated disk image image.200 with 200 blocks
 simplefs> debug
superblock:
    200 blocks
    21 inode blocks
    2688 inodes
inode 1:
    size: 1523 bytes
    direct blocks: 152 
inode 2:
    size: 105421 bytes
    direct blocks: 49 50 51 52 53 
    indirect block: 54
    indirect data blocks: 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 
inode 9:
    size: 409305 bytes
    direct blocks: 22 23 24 25 26 
    indirect block: 28
    indirect data blocks: 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 76 77 78 79 80 82 83 84 85 86 
87 88 89 90 91 92 93 94 95 96 97 98 99 100 101 102 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 1
19 120 121 122 123 124 125 126 127 128 129 130 131 132 133 134 135 136 137 138 139 140 141 142 143 144 145 146 147 1
48 149 150 151 
 simplefs> exit
Not currently mounted
closing emulated disk.
2691 disk block reads
0 disk block writes
```
This output matches the output from our own implementation of `fs_debug` with
the exception of the number of disk block reads:
```
[19:55:06]$ ./simplefs image.200 200         
opened emulated disk image image.200 with 200 blocks
 simplefs> debug
superblock:
    200 blocks
    21 inode blocks
    2688 inodes
inode 1:
    size: 1523 bytes
    direct blocks: 152
inode 2:
    size: 105421 bytes
    direct blocks: 49 50 51 52 53
    indirect block: 54
    indirect data blocks: 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75
inode 9:
    size: 409305 bytes
    direct blocks: 22 23 24 25 26
    indirect block: 28
    indirect data blocks: 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 76 77 78 79 80 82 83 84 85 86 
87 88 89 90 91 92 93 94 95 96 97 98 99 100 101 102 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 1
19 120 121 122 123 124 125 126 127 128 129 130 131 132 133 134 135 136 137 138 139 140 141 142 143 144 145 146 147 1
48 149 150 151
 simplefs> exit
Not currently mounted
closing emulated disk.
24 disk block reads
0 disk block writes
```
